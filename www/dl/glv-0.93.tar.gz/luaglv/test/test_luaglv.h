#ifndef INC_TEST_LUAGLV_H
#define INC_TEST_LUAGLV_H


#if defined (__APPLE__) || defined (OSX)
	#include "glv_binding_carbon.h"
#endif

namespace glv {


} // namespace

#endif	//INC_TEST_LUAGLV_H