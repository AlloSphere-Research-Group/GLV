#ifndef INC_GLV_OBSERVER_H
#define INC_GLV_OBSERVER_H

/*	Graphics Library of Views (GLV) - GUI Building Toolkit
	See COPYRIGHT file for authors and license information */

#include <vector>

namespace glv {


// Usage code:

	void updateValue(const Notification<Slider>& n){
		Label& l = *(Label *)n.receiver();
		char buf[16]; snprintf(buf, sizeof(buf), "%g", n.sender().value());
		l.label(buf);
	}

	void updateFocus(const Notification<Slider>& n){
		Label& l = *(Label *)n.receiver();
		l.label(n.sender().enabled(Focused) ? "Slider get focus." : "Slider lose focus.");
	}

	void main(){
		Slider slider;
		Label status;
		slider.attach(updateValue, Notification::ValueChange, &status);
		slider.attach(updateFocus, Notification::FocusChange, &status);
	}


/// Notification object

/// We assume that the sender is known at compile time, but the receiver is not.
///
template <class T>
class Notification{
public:

	enum t{
		FocusChange=0,
		ValueChange,
		NumTypes
	}

	Notification(T& sndr, void * rcvr=0)
	:	mSender(sndr), mReceiver(rcvr)
	{}

	T& sender() const { return mSender; }
	void * receiver() const { return mReceiver; }

protected:
	T& mSender;
	void * mReceiver;
	//Notification::t mType;
};




template <class Tn>
class Notifier{
public:

	typedef void (* callback)(const Tn& notification);

	void attach(callback cb, Notification::t n, void * rcvr=0){
		mHandlers[n].push_back(Handler(cb, rcvr));
	}
	
	void detach(callback cb, Notification::t n, void * rcvr=0){
		for(unsigned int i=0; i<mHandlers[n].size(); i++){
			Handler& h = mHandlers[n][i];
			if(h.handler == cb && h.receiver == rcvr) mHandlers[n].erase(mHandlers[n].begin() + i);
		}
	}

	void notify(Notification::t n){
	
		if(mHandlers[n].empty()) return;
		
		int i=mHandlers[n].size(); // call handlers in FIFO order
		while (i--){
			Handler& h = mHandlers[n][i];
			if(h.handler){
				notification.receiver(h.receiver);
				h.handler(notification);
			}
		}		
	}

protected:

	struct Handler{
		Handler(callback c, void * r): handler(c), receiver(r){}
		callback handler;
		void * receiver;
	};

	std::vector<Handler> mHandlers[Notification::NumTypes];
};





//template <class T>
//class Notification{
//public:
//	Notification(T& sndr, void * rcvr=0)
//	:	mSender(sndr), mReceiver(rcvr)
//	{}
//
//	T& sender() const { return mSender; }
//	void * receiver() const { return mReceiver; }
//
//protected:
//	T& mSender;
//	void * mReceiver;
//};
//
//
//
//
//
//template <class Tn>
//class Notifier{
//public:
//
//	typedef void (* callback)(const Tn& notification);
//
//	void attach(callback cb, void * rcvr=0){
//		mHandlers.push_back(Handler(cb, rcvr));
//	}
//	
//	void detach(callback cb, void * rcvr=0){
//		for(unsigned int i=0; i<mHandlers.size(); i++){
//			Handler& h = mHandlers[i];
//			if(h.handler == cb && h.receiver == rcvr) mHandlers.erase(mHandlers.begin() + i);
//		}
//	}
//
//	void notify(Tn& notification){
//		if(mHandlers.empty()) return;
//		
//		int i=mHandlers.size(); // call handlers in FIFO order
//		while (i--){
//			Handler& h = mHandlers[i];
//			if(h.handler){
//				notification.receiver(h.receiver);
//				h.handler(notification);
//			}
//		}		
//	}
//
//protected:
//
//	struct Handler{
//		Handler(callback c, void * r): handler(c), receiver(r){}
//		callback handler;
//		void * receiver;
//	};
//
//	std::vector<Handler> mHandlers;
//};




//class Notifier;
//
//typedef void (*glvHandler)(Notifier * sender, void * userdata); ///< Handler type
//
///// Handler functor
//class HandlerFunctor{
//public:
//	HandlerFunctor(glvHandler a, void * v=0){ handler=a; udata=v; }
//
//	glvHandler handler;
//	void * udata;
//};
//
//
//
///// Notifier
//class Notifier{
//public:
//	void attachHandler(glvHandler a, void * userdata=0);
//	void detachHandler(glvHandler a, void * userdata=0);
//	void notify();
//	
//protected:
//	std::vector<HandlerFunctor> mHandlers;
//};
//
//
//
//// Implementation ______________________________________________________________
//
//inline
//void Notifier :: notify()
//{
//	if(mHandlers.empty()) return;
//	
//	int i=mHandlers.size(); // call handlers in FIFO order
//	while (i--)	
//	{
//		if (mHandlers[i].handler) mHandlers[i].handler(this, mHandlers[i].udata);
//	}
//}
//
//inline
//void Notifier :: attachHandler (glvHandler a, void * userdata) 
//{
//	mHandlers.push_back(HandlerFunctor(a, userdata));
//}
//
//inline
//void Notifier :: detachHandler (glvHandler a, void * userdata) 
//{
//	for(unsigned int i=0; i<mHandlers.size(); i++)
//	{
//		if (mHandlers[i].handler == a && mHandlers[i].udata == userdata) mHandlers.erase(mHandlers.begin() + i);
//	}
//}


} // glv::

#endif

